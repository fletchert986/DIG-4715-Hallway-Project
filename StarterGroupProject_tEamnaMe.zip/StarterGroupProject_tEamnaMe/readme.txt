Project Made By: tEam naMe

Game: School Skipper

Team: Thomas Fletcher, Kyle Lambdin, Miah Shefer

GitHub Unity Repository: https://github.com/fletchert986/DIG-4715-Hallway-Project

Documents Folder: Team Contract, Concept Document, Production Plan, GDD, ASG, and Wireframes with menus and HUD in Xd

Builds Folder: Unity game build with all supporting files

Controller is configured for a PS4 controller; keyboard is wasd and mouse to look around

In School Skipper, you hit start in the first menu, watch a preview camera, grab your backpack from your locker, and leave
